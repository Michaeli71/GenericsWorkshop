package solutions;



import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

public class Exercise2b_Generics_MapperTest {

	@Test
	public void givenArrayOfIntegers_thanListOfStringReturnedOK() {
		Integer[] intArray = { 1, 2, 3, 4, 5 };
		List<String> stringList = Exercise02_Generics_Mapper.fromArrayToList(intArray, Object::toString);

		assertEquals(stringList, List.of("1", "2", "3", "4", "5"));
	}
}
