package examples;
public class CircleFigure extends BaseFigure {

	@Override
	public String toString() {
		return String.format("CircleFigure []");
	}

}