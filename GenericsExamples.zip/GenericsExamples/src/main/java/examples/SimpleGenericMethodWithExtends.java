package examples;

import java.util.Arrays;
import java.util.List;

public class SimpleGenericMethodWithExtends {

	public static void main(String[] args) {
		List<Integer> ints = Arrays.asList(1, 2, 3, 4, 5);
		System.out.println(sum(ints));

		List<Double> doubles = List.of(1.5d, 2d, 3d);
		System.out.println(sum(doubles));

//		List<String> strings = List.of("1", "2");
//		System.out.println(sum(strings));
	}

	private static Number sum(List<? extends Number> numbers) {
		double s = 0.0;
		
		for (Number n : numbers)
			s += n.doubleValue();
		
		return s;
	}
	
	private static Number specialsum(List<? extends Number> numbers) {
		double s = 0.0;
		
		for (Number n : numbers)
			s += n.doubleValue();
		
		
		// add VAT
		//numbers.add(s * 0.19d)
		
		return s;
	}
}
