package examples;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Hilfsklasse zur Demonstration von verschiedenen Aspekten bei Generics
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public final class Person
{
    private String name;
    private LocalDate   birthday;
    private String city;

    // needed for Reflection
    /* private */ Person()
    {        
    }
    
    public Person(final String name, final LocalDate birthday, final String city)
    {
        if (name == null || birthday == null || city == null)
            throw new IllegalArgumentException("parameters 'name', 'birthday' and 'city' must not be null!");

        this.name = name;
        this.birthday = birthday;
        this.city = city;
    }

    public final String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
    
    public LocalDate getBirthday()
    {
        return birthday;
    }

    public void setBirthday(LocalDate birthday)
    {
        this.birthday = birthday;
    }

    public final String getCity()
    {
        return city;
    }
    
    public void setCity(String city)
    {
        this.city = city;
    }


    @Override
	public boolean equals(Object other)
    {
        if (other == null) // null safe
            return false;

        if (this == other) // reflexive
            return true;

        // compare only objects of same type
        if (!this.getClass().equals(other.getClass()))
            return false;

        final Person otherPerson = (Person) other;
        return equalsImpl(otherPerson);
    }

    private boolean equalsImpl(final Person otherPerson)
    {
        return this.getName().equals(otherPerson.getName()) && this.getBirthday().equals(otherPerson.getBirthday())
               && this.getCity().equals(otherPerson.getCity());
    }

    @Override
	public String toString()
    {
        final StringBuffer buf = new StringBuffer();

        buf.append("Person: ");

        buf.append("Name='");
        buf.append(getName());
        buf.append("' ");
        buf.append("City='");
        buf.append(getCity());
        buf.append("' ");
        buf.append("Birthday='");
        buf.append(getBirthday());
        buf.append("'");

        return buf.toString();        
    }
    
    // Vermeide FindBugs Warning, obwohl diese Klasse niemals in Hash-Container verwendet wird
    @Override
    public int hashCode()
    {
    	return Objects.hash(this.name, this.birthday, this.city);
    }    
}
