package examples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VarianceIntroExamples {

	public static void main(String[] args) {
		final List<String> names = new ArrayList<>(); 
		final Set<BaseFigure> figures = new HashSet<>();
		
//		// Achtung: Kompilierfehler
//		final List<Object> names = new ArrayList<String>();
//		final Set<BaseFigure> figures = new HashSet<Circle>();
		
		arrayCovariance();
	}

	private static void arrayCovariance() {
		final Object[] names = new String[10];
		final BaseFigure[] figures = new CircleFigure[10];
	}
}
