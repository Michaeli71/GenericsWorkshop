package examples;

import java.util.ArrayList;
import java.util.List;

public class WildcardsExample {

	public static void main(String[] args) {
		List<?> intList = new ArrayList<Integer>();
		List<?> strList = new ArrayList<String>();
	}
}
