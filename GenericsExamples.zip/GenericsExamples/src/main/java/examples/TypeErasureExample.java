package examples;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TypeErasureExample {

	public static void main(String[] args) {
		final List<Person> personList = new ArrayList<>(); 
		personList.add(new Person("Max", LocalDate.now(), "Musterstadt"));
		final Person firstPerson = personList.get(0);
		
		final List personList2 = new ArrayList();
		personList2.add(new Person("Max", LocalDate.now(), "Musterstadt"));
		final Person firstPerson2 = personList.get(0);
	}

}
