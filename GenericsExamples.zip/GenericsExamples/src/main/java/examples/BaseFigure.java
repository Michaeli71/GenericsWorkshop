package examples;

public abstract class BaseFigure {
	public void printInfo() {
	}
}