package examples;

import java.util.ArrayList;
import java.util.List;

public class Generics_Motivation {

	public static void main(String[] args) {

		simpleDefintionAndUsage();
		misuseNoGenerics();
		misuseWithGenerics();
	}

	private static void simpleDefintionAndUsage() {
		List stringList = new ArrayList();
		stringList.add("Hallo");
		String str = (String) stringList.get(0);
	
		List<String> stringList2 = new ArrayList<String>();
		stringList2.add("Hallo");
		String str2 = stringList2.get(0);
	}
	
	private static void misuseNoGenerics() {
		List stringList = new ArrayList();
		stringList.add("Hallo");
		stringList.add(-1234);
		String str = (String) stringList.get(1);
	}
	
	private static void misuseWithGenerics() {	
		List<String> stringList2 = new ArrayList<String>();
		stringList2.add("Hallo");
		// stringList2.add(-1234);
		String str2 = stringList2.get(1);
	}
}
