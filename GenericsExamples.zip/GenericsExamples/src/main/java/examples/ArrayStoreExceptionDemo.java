package examples;

public class ArrayStoreExceptionDemo {

	public static void main(String[] args) 
	{		
		// Kovarianz
		Object[] values = new String[10];
		values[0] = "Michael";
		values[1] = 10; // Exception in thread "main" java.lang.ArrayStoreException: java.lang.Integer
		
		
	}
}
