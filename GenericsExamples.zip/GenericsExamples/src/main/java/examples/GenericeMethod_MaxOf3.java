package examples;

import java.util.List;

public class GenericeMethod_MaxOf3 {

	/*
	 * public static <T> T maxOf3_V1(T x, T y, T z) { T max = x;
	 * 
	 * if (y.compareTo(max) > 0) { max = y; }
	 * 
	 * if (z.compareTo(max) > 0) { max = z; }
	 * 
	 * return max; }
	 */
	
	
	// Idee: T extends Comparable<T>

	/*
	public static <T> T maxOf3_V2(<T extends Comparable<T> x, <T extends Comparable<T>> y,
			<T extends Comparable<T>> z) {
		T max = x;

		if (y.compareTo(max) > 0) {
			max = y;
		}

		if (z.compareTo(max) > 0) {
			max = z;
		}

		return max;
	}
*/ 
	
	public static <T extends Comparable<T>> T maxOf3(T x, T y, T z) {
		T max = x;

		if (y.compareTo(max) > 0) {
			max = y;
		}

		if (z.compareTo(max) > 0) {
			max = z;
		}

		return max;
	}

	
	public static <T extends Comparable<T>> T maxOf(T... values) {
		T max = values[0];
		
		for (int i = 1; i < values.length; i++)
		{
			if (values[i].compareTo(max) > 0) {
				max = values[i];
			}
		}
		return max;
	}
	
	public static <T extends Comparable<T>> T maxOf(List<T> values) {
		T max = values.get(0);
		
		for (int i = 1; i < values.size(); i++)
		{
			if (values.get(i).compareTo(max) > 0) {
				max = values.get(i);
			}
		}
		return max;
	}
	
	public static void main(String args[]) {
		System.out.printf("Max of %d, %d and %d is %d\n\n", 1, 7, 2, maxOf3(1, 7, 2));

		System.out.printf("Max of %.1f,%.1f and %.1f is %.1f\n\n", 6.6, 8.8, 7.7, maxOf3(6.6, 8.8, 7.7));

		System.out.printf("Max of %s, %s and %s is %s\n", "Java", "Python", "C#", maxOf3("Java", "Python", "C#"));
		
		// ........
		System.out.println(maxOf("A", "B", "C", "D", "E", "F"));
		System.out.println(maxOf(List.of("A", "B", "C", "D", "E", "F")));
	}
}