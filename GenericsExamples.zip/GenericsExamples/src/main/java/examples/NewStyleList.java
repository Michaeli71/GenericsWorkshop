package examples;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Beispiel für Typsicherheit durch den Einsatz von Generics
 * 
 * @author Michael Inden
 * 
 * Copyright 2011 by Michael Inden 
 */
public final class NewStyleList
{
	public static void main(final String[] args)
	{
	    final List<Person> personList = new ArrayList<>();
	    personList.add(new Person("Max", LocalDate.now(), "Musterstadt"));
	    personList.add(new Person("Moritz", LocalDate.now(), "Musterstadt"));
	    // personList.add(new Dog(''Sarah vom Auetal''));  // Compile-Error
	
	    for (int i = 0; i < personList.size(); i++)
	    {
	        final Person person = personList.get(i);
	        System.out.println(person.getName() + " aus " + person.getCity());
	    }
	}

    private NewStyleList()
    {
    }
}