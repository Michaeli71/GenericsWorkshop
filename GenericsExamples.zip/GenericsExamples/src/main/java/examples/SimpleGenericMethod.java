package examples;

import java.util.ArrayList;
import java.util.List;

public class SimpleGenericMethod {

	public static void main(String[] args) {

		// OLD STYLE ohne Diamond
		List<Double> doubles = new ArrayList<Double>();
		doubles.add(1.2);
		doubles.add(2.3);
		doubles.add(3.1415);
		doubles.add(4.5);
		System.out.println("3.1415? " + findElemFromPos(doubles, 3.1415));
		System.out.println("7.271? " + findElemFromPos(doubles, 7.271));
		

		// Java 7 Style
		List<String> names = new ArrayList<>();
		names.add("Java");
		names.add("Rocks");
		
		// Java 9 Style
		List<String> names2 = List.of("Tim", "Tom", "Peter", "Mike", "Jim", "John");
		System.out.println("Mike? " + findElemFromPos(names2, "Mike"));
		System.out.println("Mike? " + findElemFromPos(names2, "Mike", 4));
	}

	static <T> int findElemFromPos(List<T> values, T elemToFind) {
		return findElemFromPos(values, elemToFind, 0);
	}
	
	static <T> int findElemFromPos(List<T> values, T elemToFind, int startPos) {
		for (int i = startPos; i < values.size(); i++) {
			if (values.get(i).equals(elemToFind)) {
				return i;
			}
		}
		return -1;
	}
}
