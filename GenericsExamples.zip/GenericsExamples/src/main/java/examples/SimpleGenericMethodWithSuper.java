package examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SimpleGenericMethodWithSuper {

	public static void main(String[] args) {
		List<Number> ints = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
		System.out.println(addVAT(ints, 15));

		List<Number> doubles = new ArrayList<>(List.of(1.5d, 2d, 3d));
		System.out.println(addVAT(doubles, 6.5d));
	}
	
	private static List<?> addVAT(List<? super Number> numbers, Number sum) {
		
		// add VAT
		numbers.add(sum.doubleValue() * 0.19d);
		
		return numbers;
	}
}
