package examples;
public class RectFigure extends BaseFigure {

	@Override
	public String toString() {
		return String.format("RectFigure []");
	}

}