package examples;

public class ArrayCovarianceExample {

	static public class Message {

		public Message(String string) {
			
		}
	}

	public static void main(String[] args) {
		Object[] messages = new String[] { "Arrays", "sind", "kovariant" };

		messages = new Integer[] { 1, 2, 3 };

		messages = new String[] { "Back", "to", "Strings" };

		// Typfehler, weil Message nicht kompatibel zu String ist
		messages[1] = new Message("Typfehler durch Kovarianz!");
	}
}
