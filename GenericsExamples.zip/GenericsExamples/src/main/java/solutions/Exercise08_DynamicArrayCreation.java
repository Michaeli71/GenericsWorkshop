package solutions;

import java.lang.reflect.Array;

public class Exercise08_DynamicArrayCreation {

	static class Matrix<T> {
		private T[][] values;
		private int rows;
		private int cols;

		@SuppressWarnings("unchecked")
		public Matrix(int r, int c, Class<T> type) {
			rows = r;
			cols = c;
			// values = (T[][]) new Object[rows][cols];
			values = (T[][]) Array.newInstance(type, rows, cols);
		}

		public void set(int r, int c, T v) {
			values[r][c] = v;
		}

		public T get(int r, int c) {
			return values[r][c];
		}
	}
	
	public static void main(String[] args) {
		Matrix<String> matrix1 = new Matrix<>(4, 3, String.class);
		matrix1.set(1, 2, "DREI");
		System.out.println(matrix1.get(1, 2));
		
		
		Matrix<Integer> matrix2 = new Matrix<>(4, 3, Integer.class);
		matrix2.set(2, 2, 4711);
		System.out.println(matrix2.get(2, 2));
	}
}
