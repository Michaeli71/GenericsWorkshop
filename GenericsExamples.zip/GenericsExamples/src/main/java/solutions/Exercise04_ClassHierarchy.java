package solutions;

import java.util.Arrays;
import java.util.List;

public class Exercise04_ClassHierarchy {

	static class BaseFigure
	{
		void printInfo()
		{
			System.out.println("BaseFigure");
		}
	}
	
	static class Rect extends BaseFigure
	{
		@Override
		void printInfo()
		{
			System.out.println("Rect");
		}
	}

	static class Circle extends BaseFigure
	{
		@Override
		void printInfo()
		{
			System.out.println("Circle");
		}
	}

	static void printInfo(BaseFigure[] figures)
	{
		Arrays.asList(figures).forEach(fig -> fig.printInfo());
	}
	
	public static void main(String[] args) {
		
		BaseFigure[] figures = { new Rect(), new Circle(), new Rect() };				
		printInfo(figures);
		
		Rect[] rects = { new Rect(), new Rect() };				
		printInfo(rects);

		
		//
		System.out.println("-------------------- List + Generics ---------------------");
		List<BaseFigure> figures2 = List.of(new Rect(), new Circle(), new Rect());
		printInfo(figures2);
		
		List<Rect> rects2 = List.of(new Rect(), new Rect());
		// The method printInfo(Exercise04_ClassHierarchy.BaseFigure[]) in the type Exercise04_ClassHierarchy is not applicable for the arguments (List<Exercise04_ClassHierarchy.Rect>)
		// printInfo(rects2);
		printInfoWithCovariance(rects2);
	}
	
	
	static void printInfo(List<BaseFigure> figures)
	{
		figures.forEach(fig -> fig.printInfo());
	}
	
	static void printInfoWithCovariance(List<? extends BaseFigure> figures)
	{
		figures.forEach(fig -> fig.printInfo());
	}
}
