package solutions;

public class Exercise05_Generic_DataContainer {

	public static void main(String[] args) {

		snippet1();
		snippet2();
		snippet3();
		snippet4();
	}

	private static void snippet1() {
		// KOVARIANZ
		// AnimalHouse<Animal> house = new AnimalHouse<Cat>();

		AnimalHouse<? extends Animal> house = new AnimalHouse<Cat>();
	}

	private static void snippet2() {
		// KONTRAVARIANZ
		// AnimalHouse<Dog> house = new AnimalHouse<Animal>();

		AnimalHouse<? super Dog> house = new AnimalHouse<Animal>();
	}

	private static void snippet3() {
		AnimalHouse<?> house = new AnimalHouse<Cat>();
		// house.setAnimal(new Cat());
	}

	private static void snippet4() {
		AnimalHouse house = new AnimalHouse();
		house.setAnimal(new Dog());
	}

	public static class AnimalHouse<E> {
		private E animal;
	
		public void setAnimal(E x) {
			animal = x;
		}
	
		public E getAnimal() {
			return animal;
		}
	}
	
	public static class Animal {
	}
	
	public static class Cat extends Animal {
	}
	
	public static class Dog extends Animal {
	}
}
