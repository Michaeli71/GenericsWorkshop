package solutions;

import java.util.Arrays;

public class Exercise03_InsertionSort {
	private Exercise03_InsertionSort() {
	}

	public static <T extends Comparable<T>> void insertionSort(T[] values) {
		for (int i = 1; i < values.length; i++) {
			
			// Prüfe, ob aktuelles Element grösser als Vorgänger
			int currentIdx = i;
			
			while (currentIdx > 0 && values[currentIdx - 1].compareTo(values[currentIdx]) > 0){
				swap(values, currentIdx - 1, currentIdx);
				currentIdx--;
			}
		}
	}

	public static <T> void swap(final T[] values, final int pos1, final int pos2) {
		final T temp = values[pos1];
		values[pos1] = values[pos2];
		values[pos2] = temp;
	}
	
	public static void main(String[] args) {
		String[] names = { "Peter", "Anne", "Fritz", "Otto", "Sophie" };
		
		insertionSort(names);
		
		System.out.println(Arrays.toString(names));
	}
	
}