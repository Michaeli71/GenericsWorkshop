package solutions;

import java.util.LinkedList;

public class Exercise01_Queue {

	class Queue<T> {
		private LinkedList<T> items = new LinkedList<>();

		public void enqueue(T item) {
			items.addLast(item);
		}

		public T dequeue() {
			return items.removeFirst();
		}

		public boolean isEmpty() {
			return (items.size() == 0);
		}
	}
}
