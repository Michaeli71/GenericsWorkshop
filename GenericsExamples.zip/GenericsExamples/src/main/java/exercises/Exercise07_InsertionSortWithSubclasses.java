package exercises;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Exercise07_InsertionSortWithSubclasses {

	static class Person {
		public String name;
		public LocalDate birthday;

		public Person(String name, LocalDate birthday) {
			this.name = name;
			this.birthday = birthday;
		}

		@Override
		public String toString() {
			return "Person [name=" + name + ", birthday=" + birthday + "]";
		}
	}

	static class Student extends Person {
		public String university;
		public String registrationNumber;

		public Student(String name, LocalDate birthday, String university, String registrationNumber) {
			super(name, birthday);
			this.university = university;
			this.registrationNumber = registrationNumber;
		}

		@Override
		public String toString() {
			return "Student [university=" + university + ", registrationNumber=" + registrationNumber + ", toString()="
					+ super.toString() + "]";
		}
	}

	private Exercise07_InsertionSortWithSubclasses() {
	}

	public static <T extends Comparable<T>> void insertionSort(T[] values) {
		for (int i = 1; i < values.length; i++) {

			// Prüfe, ob aktuelles Element grösser als Vorgänger
			int currentIdx = i;

			while (currentIdx > 0 && values[currentIdx - 1].compareTo(values[currentIdx]) > 0) {
				swap(values, currentIdx - 1, currentIdx);
				currentIdx--;
			}
		}
	}

	public static <T> void swap(final T[] values, final int pos1, final int pos2) {
		final T temp = values[pos1];
		values[pos1] = values[pos2];
		values[pos2] = temp;
	}
	
	public static <T> void swap(final List<T> values, final int pos1, final int pos2) {
		final T temp = values.get(pos1);
		values.set(pos1, values.get(pos2));
		values.set(pos2, temp);
	}

	public static void main(String[] args) {
		String[] names = { "Peter", "Anne", "Fritz", "Otto", "Sophie" };

		insertionSort(names);

		System.out.println(Arrays.toString(names));

		// Vererbungshierarchie
		Person tim = new Person("Tim", LocalDate.of(1971, 3, 27));
		Person james = new Person("James", LocalDate.of(2001, 5, 21));
		Student mike = new Student("Merten", LocalDate.of(1997, 6, 16), "Oldenburg", "47155830");
		Student stefan = new Student("Stefan", LocalDate.of(1971, 5, 12), "Oldenburg", "47151230");
		Student tommy = new Student("Tommy", LocalDate.of(2001, 1, 7), "Aachen", "1234567");

		List<Person> people = new ArrayList<>(List.of(tim, james, mike, stefan));
		List<Student> students = new ArrayList<>(List.of(mike, stefan, tommy));

		// AgeComparataor, der für Person und Student anwendbar sein soll
		Comparator<Person> byAge = (p1, p2) -> {
			return Period.between(p1.birthday, p2.birthday).getDays();
		};

		// TODO
		
		/*
		insertionSort(people, byAge);
		System.out.println(people);

		insertionSort(students, byAge);
		System.out.println(students);
		*/
	}
}