package exercises;

import java.util.ArrayList;
import java.util.List;

import examples.BaseFigure;
import examples.CircleFigure;
import examples.RectFigure;

public class Exercise06_Copy {

	public static void copy(final List<BaseFigure> src, final List<BaseFigure> dest) {
		for (final BaseFigure figure : src) {
			dest.add(figure);
		}
	}
	
	public static void main(String[] args) {

		copyMixedSources();
		copyDifferentDestinations();
		copyPlainCircles();
	}

	private static void copyMixedSources() {

		final List<BaseFigure> mixed = new ArrayList<>();
		mixed.add(new CircleFigure());
		mixed.add(new RectFigure());

		// Definition von Zieldatenstruktur
		final List<BaseFigure> baseFigures = new ArrayList<>();

		copy(mixed, baseFigures);
		System.out.println(baseFigures);
	}

	private static void copyDifferentDestinations() {

		final List<CircleFigure> circles = new ArrayList<>();
		circles.add(new CircleFigure());
		circles.add(new CircleFigure());

		final List<RectFigure> rects = new ArrayList<>();
		rects.add(new RectFigure());
		rects.add(new RectFigure());

		// Definition von Zieldatenstrukturen
		final List<BaseFigure> baseFigures = new ArrayList<>();
		final List<Object> objects = new ArrayList<>();

		// Kovariante Eingabe und kontravarianter Zielparameter
		//copy(circles, baseFigures);
		System.out.println(baseFigures);

		//copy(rects, objects);
		System.out.println(objects);
	}

	private static void copyPlainCircles() {
		final List<CircleFigure> circlesSrc = new ArrayList<>();
		// Füllen der Liste ...
		circlesSrc.add(new CircleFigure());
		circlesSrc.add(new CircleFigure());

		final List<CircleFigure> circlesDest = new ArrayList<>();

		//copy(circlesSrc, circlesDest);
		System.out.println(circlesDest);
	}
}
