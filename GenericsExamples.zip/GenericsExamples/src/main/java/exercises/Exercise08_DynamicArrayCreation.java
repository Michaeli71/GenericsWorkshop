package exercises;

public class Exercise08_DynamicArrayCreation {

	static class Matrix<T> {
		private T[][] values;
		private int rows;
		private int cols;

		public Matrix(int r, int c) {
			rows = r;
			cols = c;
			// values = new T[rows][cols]; // THIS WILL NOT COMPILE
		}

		public void set(int r, int c, T v) {
			values[r][c] = v;
		}

		public T get(int r, int c) {
			return values[r][c];
		}
	}

	public class Matrix2<T extends Object> {
		private Object[][] values;
		private int rows;
		private int cols;

		public Matrix2(int r, int c) {
			rows = r;
			cols = c;
			values = new Object[rows][cols]; // WARNING
		}

		public void set(int r, int c, T v) {
			values[r][c] = v;
		}

		public T get(int r, int c) {
			return (T) values[r][c];
		}
	}

	public static void main(String[] args) {
		Matrix<String> matrix1 = new Matrix<>(4, 3);
		matrix1.set(1, 2, "DREI");
		System.out.println(matrix1.get(1, 2));

		Matrix<Integer> matrix2 = new Matrix<>(4, 3);
		matrix2.set(2, 2, 4711);
		System.out.println(matrix2.get(2, 2));
	}
}
