package exercises;

public class Exercise03_InsertionSort {
	private Exercise03_InsertionSort() {
	}

	public static void insertionSort(int[] values) {
		for (int i = 1; i < values.length; i++) {
			// Prüfe, ob aktuelles Element grösser als Vorgänger
			int currentIdx = i;
			while (currentIdx > 0 && values[currentIdx - 1] > values[currentIdx]) {
				swap(values, currentIdx - 1, currentIdx);
				currentIdx--;
			}
		}
	}

	public static void swap(final int[] values, final int pos1, final int pos2) {
		final int temp = values[pos1];
		values[pos1] = values[pos2];
		values[pos2] = temp;
	}
}