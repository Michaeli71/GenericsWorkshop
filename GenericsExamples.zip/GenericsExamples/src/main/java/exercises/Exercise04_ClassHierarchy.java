package exercises;

import java.util.Arrays;

public class Exercise04_ClassHierarchy {

	static class BaseFigure
	{
		void printInfo()
		{
			System.out.println("BaseFigure");
		}
	}
	
	static class Rect extends BaseFigure
	{
		void printInfo()
		{
			System.out.println("Rect");
		}
	}

	static class Circle extends BaseFigure
	{
		void printInfo()
		{
			System.out.println("Circle");
		}
	}

	static void printInfo(BaseFigure[] figures)
	{
		Arrays.asList(figures).forEach(fig -> fig.printInfo());
	}
	
	public static void main(String[] args) {
		
		BaseFigure[] figures = { new Rect(), new Circle(), new Rect() };				
		printInfo(figures);
		
		// Aufgabe: Wieso geht das eigentlich? ;-)
		Rect[] rects = { new Rect(), new Rect() };				
		printInfo(rects);
		
		System.out.println("-------------------- List + Generics ---------------------");
		
		// TODO
	}
}
